public interface IShootStrategy
{
    void Shoot(ShootAbility ability);
}
